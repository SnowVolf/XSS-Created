package com.trablone.csscreated;

public class Item
{
	public String title;
	public String data;
	public long id;
}
