package com.trablone.csscreated;

public interface FragmentLifecycle
{
	public void onResumeFragment();
	public void onPauseFragment();
}
