function jump_to_page(pag){
    injectedObject.jumpToPage(pag);
}